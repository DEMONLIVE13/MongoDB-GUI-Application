# ⚽ FootballDB — MongoDB Manager

Aplikacja desktopowa WPF (C# / .NET 8) do zarządzania bazą danych piłkarskich z MongoDB.

---

## Wymagania

| Komponent            | Wersja          |
|----------------------|-----------------|
| .NET SDK             | **8.0+**        |
| MongoDB              | **6.0 / 7.0+**  |
| Windows              | 10 / 11         |

### Instalacja .NET 8 SDK
https://dotnet.microsoft.com/download/dotnet/8.0

### Instalacja MongoDB (Community)
https://www.mongodb.com/try/download/community

---

## Szybki start

```bash
# Sklonuj / rozpakuj projekt, następnie:
cd FootballDB
dotnet restore
dotnet run
```

Lub zbuduj plik `.exe`:
```bash
dotnet publish -c Release -r win-x64 --self-contained true -o ./publish
```

---

## Funkcje aplikacji

### 🔌 Połączenie
- Konfigurowalne połączenie (connection string + nazwa bazy)
- Wskaźnik statusu połączenia (zielona/czerwona kropka)
- Domyślnie: `mongodb://localhost:27017` / baza `footballdb`

### 📊 Kolekcje (11 zakładek)
| Zakładka        | Kolekcja        | Pola                                                   |
|-----------------|-----------------|--------------------------------------------------------|
| 🏆 Ligi         | leagues         | league_id, name, country, season                       |
| ⚽ Drużyny      | teams           | team_id, name, city, league_id, founded_year           |
| 🏟 Stadiony     | stadiums        | stadium_id, name, capacity, city                       |
| 👟 Zawodnicy    | players         | player_id, first/last_name, birth_date, nationality... |
| 👔 Trenerzy     | coaches         | coach_id, first/last_name, birth_date, nationality...  |
| 🔶 Sędziowie    | referees        | referee_id, first/last_name, nationality               |
| 🎮 Mecze        | matches         | match_id, home/away_team_id, match_date, scores...     |
| ⚡ Zdarzenia    | match_events    | event_id, match_id, player_id, event_type, minute      |
| 💰 Transfery    | transfers       | transfer_id, player_id, from/to_team_id, fee...        |
| 🤝 Sponsorzy    | sponsors        | sponsor_id, name, industry                             |
| 🎯 Spon. Drużyn | team_sponsors   | team_sponsor_id, team_id, sponsor_id, amount           |

### ✏️ CRUD
- **Dodaj** — formularz z domyślnymi wartościami i podpowiedziami pól
- **Edytuj** — edycja wybranego rekordu (dwuklik lub przycisk)
- **Usuń** — z potwierdzeniem i podglądem rekordu
- **Odśwież** — ponowne pobranie danych z MongoDB

### 🔧 Generator danych
Port procedury PL/SQL `GENERATE_FOOTBALL_DATA`. Parametry:
- Regulowane suwakami (min/max na każdą kolekcję)
- Łącznie generuje relacyjnie spójne dane (ID między kolekcjami)
- Dane są **dodawane** (nie nadpisują istniejących)

Domyślne wartości:
```
Ligi: 5 | Stadiony: 20 | Sędziowie: 15 | Sponsorzy: 10 | Drużyny: 40
Trenerzy: 50 | Zawodnicy: 800 | Mecze: 800 | Zdarzenia: 5000
Transfery: 500 | Spon. drużyn: 100
```

### 📥📤 Import / Eksport JSON
**Eksport całej bazy:**
```json
{
  "leagues":  [ { "league_id": 1, "name": "League 1", ... }, ... ],
  "teams":    [ ... ],
  ...
}
```

**Eksport/import pojedynczej kolekcji:**
```json
[ { "player_id": 1, "first_name": "Robert", ... }, ... ]
```

- Eksport → plik `.json` (przez dialog zapisu)
- Import → dodaje rekordy bez nadpisywania

### 🔍 Wyszukiwanie
- Szuka w polach tekstowych (name, first_name, last_name, city, nationality)
- Aktywne dla bieżącej zakładki
- Case-insensitive (regex)

### 🗑️ Wyczyść bazę
Usuwa wszystkie dokumenty ze wszystkich kolekcji (z potwierdzeniem).

---

## Struktura projektu

```
FootballDB/
├── FootballDB.csproj
├── App.xaml / App.xaml.cs          — style globalne aplikacji
├── MainWindow.xaml / .cs           — główne okno z zakładkami
├── Services/
│   ├── MongoService.cs             — operacje CRUD na MongoDB
│   ├── DataGenerator.cs            — generator danych piłkarskich
│   ├── ImportExportService.cs      — import/eksport JSON
│   └── CollectionMeta.cs           — schema kolekcji i opisy pól
└── Windows/
    ├── EditWindow.xaml / .cs       — formularz dodawania / edycji
    └── GeneratorWindow.xaml / .cs  — okno generatora z suwakami
```

---

## Przykład użycia

1. Uruchom MongoDB: `mongod --dbpath C:\data\db`
2. Uruchom aplikację FootballDB
3. Kliknij **Połącz**
4. Kliknij **🔧 Generuj dane** → ustaw ilości → **Generuj**
5. Przeglądaj dane w zakładkach
6. Użyj **📤 Eksportuj JSON** aby zapisać dane
7. Użyj **📥 Importuj JSON** aby wczytać dane z pliku

---

## Zależności NuGet

| Pakiet              | Wersja  |
|---------------------|---------|
| MongoDB.Driver      | 2.28.0  |
| Newtonsoft.Json     | 13.0.3  |
