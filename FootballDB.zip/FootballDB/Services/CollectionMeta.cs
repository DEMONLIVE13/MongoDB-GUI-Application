namespace FootballDB.Services
{
    /// <summary>Field descriptor used when creating new documents.</summary>
    public record FieldDef(string Name, string DefaultValue = "", string Hint = "");

    public static class CollectionMeta
    {
        // Ordered list of all managed collections
        public static readonly string[] Names =
        {
            "leagues", "teams", "stadiums", "players", "coaches",
            "referees", "matches", "match_events", "transfers", "sponsors", "team_sponsors"
        };

        // Display names + emoji
        public static readonly Dictionary<string, string> DisplayNames = new()
        {
            ["leagues"]      = "🏆 Ligi",
            ["teams"]        = "⚽ Drużyny",
            ["stadiums"]     = "🏟 Stadiony",
            ["players"]      = "👟 Zawodnicy",
            ["coaches"]      = "👔 Trenerzy",
            ["referees"]     = "🔶 Sędziowie",
            ["matches"]      = "🎮 Mecze",
            ["match_events"] = "⚡ Zdarzenia",
            ["transfers"]    = "💰 Transfery",
            ["sponsors"]     = "🤝 Sponsorzy",
            ["team_sponsors"]= "🎯 Spon. Drużyn"
        };

        // Default fields for new-document form (excluding _id)
        public static readonly Dictionary<string, FieldDef[]> Fields = new()
        {
            ["leagues"] = new FieldDef[]
            {
                new("league_id",  "1",      "Unikalny identyfikator ligi"),
                new("name",       "Liga X",  "Nazwa ligi"),
                new("country",    "Poland",  "Kraj"),
                new("season",     "2025",    "Sezon (rok)")
            },
            ["teams"] = new FieldDef[]
            {
                new("team_id",      "1",              "ID drużyny"),
                new("name",         "FC Example",     "Nazwa drużyny"),
                new("city",         "Warsaw",         "Miasto"),
                new("league_id",    "1",              "ID ligi"),
                new("founded_year", "2000",           "Rok założenia")
            },
            ["stadiums"] = new FieldDef[]
            {
                new("stadium_id", "1",          "ID stadionu"),
                new("name",       "Arena X",    "Nazwa stadionu"),
                new("capacity",   "50000",      "Pojemność"),
                new("city",       "Warsaw",     "Miasto")
            },
            ["players"] = new FieldDef[]
            {
                new("player_id",   "1",          "ID zawodnika"),
                new("first_name",  "Jan",        "Imię"),
                new("last_name",   "Kowalski",   "Nazwisko"),
                new("birth_date",  "1995-01-01", "Data urodzenia (YYYY-MM-DD)"),
                new("nationality", "Poland",     "Narodowość"),
                new("team_id",     "1",          "ID drużyny"),
                new("position",    "Midfielder", "Goalkeeper/Defender/Midfielder/Forward")
            },
            ["coaches"] = new FieldDef[]
            {
                new("coach_id",    "1",          "ID trenera"),
                new("first_name",  "Adam",       "Imię"),
                new("last_name",   "Nowak",      "Nazwisko"),
                new("birth_date",  "1975-06-15", "Data urodzenia (YYYY-MM-DD)"),
                new("nationality", "Poland",     "Narodowość"),
                new("team_id",     "1",          "ID drużyny")
            },
            ["referees"] = new FieldDef[]
            {
                new("referee_id",  "1",       "ID sędziego"),
                new("first_name",  "Piotr",   "Imię"),
                new("last_name",   "Wiśniak", "Nazwisko"),
                new("nationality", "Poland",  "Narodowość")
            },
            ["matches"] = new FieldDef[]
            {
                new("match_id",     "1",          "ID meczu"),
                new("league_id",    "1",          "ID ligi"),
                new("home_team_id", "1",          "ID drużyny gospodarzy"),
                new("away_team_id", "2",          "ID drużyny gości"),
                new("match_date",   "2025-03-01", "Data meczu (YYYY-MM-DD)"),
                new("stadium_id",   "1",          "ID stadionu"),
                new("referee_id",   "1",          "ID sędziego"),
                new("home_score",   "0",          "Gole gospodarzy"),
                new("away_score",   "0",          "Gole gości")
            },
            ["match_events"] = new FieldDef[]
            {
                new("event_id",    "1",          "ID zdarzenia"),
                new("match_id",    "1",          "ID meczu"),
                new("player_id",   "1",          "ID zawodnika"),
                new("event_type",  "GOAL",       "GOAL/YELLOW_CARD/RED_CARD/SUBSTITUTION"),
                new("minute",      "45",         "Minuta (1-90)"),
                new("description", "Event desc", "Opis zdarzenia")
            },
            ["transfers"] = new FieldDef[]
            {
                new("transfer_id",   "1",          "ID transferu"),
                new("player_id",     "1",          "ID zawodnika"),
                new("from_team_id",  "1",          "ID drużyny źródłowej"),
                new("to_team_id",    "2",          "ID drużyny docelowej"),
                new("transfer_date", "2024-07-01", "Data transferu (YYYY-MM-DD)"),
                new("fee",           "1000000",    "Kwota transferu (PLN/EUR)")
            },
            ["sponsors"] = new FieldDef[]
            {
                new("sponsor_id", "1",        "ID sponsora"),
                new("name",       "Sponsor X","Nazwa firmy"),
                new("industry",   "Sport",    "Branża")
            },
            ["team_sponsors"] = new FieldDef[]
            {
                new("team_sponsor_id", "1",       "ID rekordu"),
                new("team_id",         "1",       "ID drużyny"),
                new("sponsor_id",      "1",       "ID sponsora"),
                new("amount",          "500000",  "Kwota sponsoringu")
            }
        };
    }
}
