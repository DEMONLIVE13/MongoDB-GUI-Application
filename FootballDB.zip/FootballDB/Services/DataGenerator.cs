using MongoDB.Bson;

namespace FootballDB.Services
{
    public class GeneratorConfig
    {
        public int Leagues      { get; set; } = 5;
        public int Stadiums     { get; set; } = 20;
        public int Referees     { get; set; } = 15;
        public int Sponsors     { get; set; } = 10;
        public int Teams        { get; set; } = 40;
        public int Coaches      { get; set; } = 50;
        public int Players      { get; set; } = 800;
        public int Matches      { get; set; } = 800;
        public int MatchEvents  { get; set; } = 5000;
        public int Transfers    { get; set; } = 500;
        public int TeamSponsors { get; set; } = 100;
    }

    public class GeneratorResult
    {
        public Dictionary<string, int> Counts { get; } = new();
        public Dictionary<string, List<BsonDocument>> Data { get; } = new();
    }

    public class DataGenerator
    {
        private readonly Random _rnd = new();

        private readonly string[] _firstName = {
            "Robert","Lionel","Cristiano","Kevin","Mohamed","Erling","Kylian",
            "Harry","Luka","Thomas","Bruno","Marcus","Jamal","Phil","Declan",
            "Jude","Pedri","Gavi","Vinicius","Rodri"
        };
        private readonly string[] _lastName = {
            "Lewandowski","Messi","Ronaldo","De Bruyne","Salah","Haaland","Mbappe",
            "Kane","Modric","Muller","Fernandes","Rashford","Musiala","Foden","Rice",
            "Bellingham","Junior","Silva","Neymar","Mbappe"
        };
        private readonly string[] _teamBase = {
            "FC Barcelona","Real Madrid","Manchester United","Bayern Munich",
            "Juventus","Liverpool","PSG","Ajax","Legia","Lech Poznan"
        };
        private readonly string[] _cities = {
            "Madrid","Barcelona","Manchester","Munich","Turin",
            "Liverpool","Paris","Amsterdam","Warsaw","Poznan"
        };
        private readonly string[] _positions    = { "Goalkeeper","Defender","Midfielder","Forward" };
        private readonly string[] _eventTypes   = { "GOAL","YELLOW_CARD","RED_CARD","SUBSTITUTION" };
        private readonly string[] _countries    = { "England","Spain","Germany","France","Italy","Poland","Netherlands","Portugal","Brazil","Argentina" };
        private readonly string[] _industries   = { "Sport","Technology","Finance","Food & Beverage","Automotive","Media","Insurance","Retail" };

        // ── Public entry point ─────────────────────────────────────────────────

        public GeneratorResult Generate(GeneratorConfig cfg)
        {
            var result = new GeneratorResult();

            var leagues      = GenLeagues(cfg.Leagues);
            var stadiums     = GenStadiums(cfg.Stadiums);
            var referees     = GenReferees(cfg.Referees);
            var sponsors     = GenSponsors(cfg.Sponsors);
            var teams        = GenTeams(cfg.Teams, cfg.Leagues);
            var coaches      = GenCoaches(cfg.Coaches, cfg.Teams);
            var players      = GenPlayers(cfg.Players, cfg.Teams);
            var matches      = GenMatches(cfg.Matches, cfg.Leagues, cfg.Teams, cfg.Stadiums, cfg.Referees);
            var matchEvents  = GenMatchEvents(cfg.MatchEvents, cfg.Matches, cfg.Players);
            var transfers    = GenTransfers(cfg.Transfers, cfg.Players, cfg.Teams);
            var teamSponsors = GenTeamSponsors(cfg.TeamSponsors, cfg.Teams, cfg.Sponsors);

            result.Data["leagues"]       = leagues;
            result.Data["stadiums"]      = stadiums;
            result.Data["referees"]      = referees;
            result.Data["sponsors"]      = sponsors;
            result.Data["teams"]         = teams;
            result.Data["coaches"]       = coaches;
            result.Data["players"]       = players;
            result.Data["matches"]       = matches;
            result.Data["match_events"]  = matchEvents;
            result.Data["transfers"]     = transfers;
            result.Data["team_sponsors"] = teamSponsors;

            foreach (var kv in result.Data)
                result.Counts[kv.Key] = kv.Value.Count;

            return result;
        }

        // ── Private generators ─────────────────────────────────────────────────

        private List<BsonDocument> GenLeagues(int n)
        {
            var list = new List<BsonDocument>();
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["league_id"] = i,
                    ["name"]      = $"League {i}",
                    ["country"]   = _countries[i % _countries.Length],
                    ["season"]    = 2025
                });
            return list;
        }

        private List<BsonDocument> GenStadiums(int n)
        {
            var list = new List<BsonDocument>();
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["stadium_id"] = i,
                    ["name"]       = $"Stadium {i}",
                    ["capacity"]   = _rnd.Next(20000, 90001),
                    ["city"]       = _cities[i % _cities.Length]
                });
            return list;
        }

        private List<BsonDocument> GenReferees(int n)
        {
            var list = new List<BsonDocument>();
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["referee_id"]  = i,
                    ["first_name"]  = _firstName[i % _firstName.Length],
                    ["last_name"]   = _lastName[i % _lastName.Length],
                    ["nationality"] = _countries[i % _countries.Length]
                });
            return list;
        }

        private List<BsonDocument> GenSponsors(int n)
        {
            var list = new List<BsonDocument>();
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["sponsor_id"] = i,
                    ["name"]       = $"Sponsor {i}",
                    ["industry"]   = _industries[i % _industries.Length]
                });
            return list;
        }

        private List<BsonDocument> GenTeams(int n, int leagueCount)
        {
            var list = new List<BsonDocument>();
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["team_id"]      = i,
                    ["name"]         = $"{_teamBase[i % _teamBase.Length]} {i}",
                    ["city"]         = _cities[i % _cities.Length],
                    ["league_id"]    = (i % Math.Max(1, leagueCount)) + 1,
                    ["founded_year"] = 1900 + _rnd.Next(0, 121)
                });
            return list;
        }

        private List<BsonDocument> GenCoaches(int n, int teamCount)
        {
            var list = new List<BsonDocument>();
            var baseDate = new DateTime(1970, 1, 1);
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["coach_id"]    = i,
                    ["first_name"]  = _firstName[i % _firstName.Length],
                    ["last_name"]   = _lastName[i % _lastName.Length],
                    ["birth_date"]  = baseDate.AddDays(_rnd.Next(0, 18251)).ToString("yyyy-MM-dd"),
                    ["nationality"] = _countries[i % _countries.Length],
                    ["team_id"]     = (i % Math.Max(1, teamCount)) + 1
                });
            return list;
        }

        private List<BsonDocument> GenPlayers(int n, int teamCount)
        {
            var list = new List<BsonDocument>();
            var baseDate = new DateTime(1985, 1, 1);
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["player_id"]   = i,
                    ["first_name"]  = _firstName[i % _firstName.Length],
                    ["last_name"]   = _lastName[i % _lastName.Length],
                    ["birth_date"]  = baseDate.AddDays(_rnd.Next(0, 7301)).ToString("yyyy-MM-dd"),
                    ["nationality"] = _countries[i % _countries.Length],
                    ["team_id"]     = (i % Math.Max(1, teamCount)) + 1,
                    ["position"]    = _positions[i % _positions.Length]
                });
            return list;
        }

        private List<BsonDocument> GenMatches(int n, int leagueCount, int teamCount, int stadiumCount, int refCount)
        {
            var list = new List<BsonDocument>();
            var baseDate = new DateTime(2025, 1, 1);
            int tc = Math.Max(2, teamCount);
            for (int i = 1; i <= n; i++)
            {
                int home = (i % tc) + 1;
                int away = ((i + 7) % tc) + 1;
                if (home == away) away = (away % tc) + 1;
                list.Add(new BsonDocument {
                    ["match_id"]      = i,
                    ["league_id"]     = (i % Math.Max(1, leagueCount)) + 1,
                    ["home_team_id"]  = home,
                    ["away_team_id"]  = away,
                    ["match_date"]    = baseDate.AddDays(_rnd.Next(0, 365)).ToString("yyyy-MM-dd"),
                    ["stadium_id"]    = (i % Math.Max(1, stadiumCount)) + 1,
                    ["referee_id"]    = (i % Math.Max(1, refCount)) + 1,
                    ["home_score"]    = _rnd.Next(0, 7),
                    ["away_score"]    = _rnd.Next(0, 7)
                });
            }
            return list;
        }

        private List<BsonDocument> GenMatchEvents(int n, int matchCount, int playerCount)
        {
            var list = new List<BsonDocument>();
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["event_id"]   = i,
                    ["match_id"]   = (i % Math.Max(1, matchCount)) + 1,
                    ["player_id"]  = (i % Math.Max(1, playerCount)) + 1,
                    ["event_type"] = _eventTypes[i % _eventTypes.Length],
                    ["minute"]     = _rnd.Next(1, 91),
                    ["description"]= $"Event {i}"
                });
            return list;
        }

        private List<BsonDocument> GenTransfers(int n, int playerCount, int teamCount)
        {
            var list = new List<BsonDocument>();
            var baseDate = new DateTime(2024, 1, 1);
            int tc = Math.Max(2, teamCount);
            for (int i = 1; i <= n; i++)
            {
                int from = (i % tc) + 1;
                int to   = ((i + 3) % tc) + 1;
                if (from == to) to = (to % tc) + 1;
                list.Add(new BsonDocument {
                    ["transfer_id"]   = i,
                    ["player_id"]     = (i % Math.Max(1, playerCount)) + 1,
                    ["from_team_id"]  = from,
                    ["to_team_id"]    = to,
                    ["transfer_date"] = baseDate.AddDays(_rnd.Next(0, 501)).ToString("yyyy-MM-dd"),
                    ["fee"]           = _rnd.Next(100_000, 60_000_001)
                });
            }
            return list;
        }

        private List<BsonDocument> GenTeamSponsors(int n, int teamCount, int sponsorCount)
        {
            var list = new List<BsonDocument>();
            for (int i = 1; i <= n; i++)
                list.Add(new BsonDocument {
                    ["team_sponsor_id"] = i,
                    ["team_id"]         = (i % Math.Max(1, teamCount)) + 1,
                    ["sponsor_id"]      = (i % Math.Max(1, sponsorCount)) + 1,
                    ["amount"]          = _rnd.Next(100_000, 5_000_001)
                });
            return list;
        }
    }
}
