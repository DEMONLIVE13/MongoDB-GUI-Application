using System.IO;
using MongoDB.Bson;
using MongoDB.Bson.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace FootballDB.Services
{
    public static class ImportExportService
    {
        private static readonly JsonWriterSettings RelaxedSettings = new()
        {
            OutputMode = JsonOutputMode.RelaxedExtendedJson
        };

        // ── Full database export ───────────────────────────────────────────────

        public static void ExportDatabase(Dictionary<string, List<BsonDocument>> data, string filePath)
        {
            var root = new JObject();
            foreach (var (coll, docs) in data)
            {
                var arr = new JArray();
                foreach (var doc in docs)
                    arr.Add(DocToJObject(doc));
                root[coll] = arr;
            }
            System.IO.File.WriteAllText(filePath, root.ToString(Formatting.Indented));
        }

        public static Dictionary<string, List<BsonDocument>> ImportDatabase(string filePath)
        {
            var result = new Dictionary<string, List<BsonDocument>>();
            var text   = System.IO.File.ReadAllText(filePath);
            var root   = JObject.Parse(text);

            foreach (var prop in root.Properties())
            {
                var docs = new List<BsonDocument>();
                if (prop.Value is JArray arr)
                    foreach (var item in arr)
                        docs.Add(BsonDocument.Parse(item.ToString()));
                result[prop.Name] = docs;
            }
            return result;
        }

        // ── Single collection export ───────────────────────────────────────────

        public static void ExportCollection(List<BsonDocument> docs, string filePath)
        {
            var arr = new JArray();
            foreach (var doc in docs)
                arr.Add(DocToJObject(doc));
            System.IO.File.WriteAllText(filePath, arr.ToString(Formatting.Indented));
        }

        public static List<BsonDocument> ImportCollection(string filePath)
        {
            var text = System.IO.File.ReadAllText(filePath);
            var list = new List<BsonDocument>();

            // Support both array [ {...}, ... ] and object { "collection": [...] }
            var token = JToken.Parse(text);
            if (token is JArray arr)
            {
                foreach (var item in arr)
                    list.Add(BsonDocument.Parse(item.ToString()));
            }
            else if (token is JObject obj)
            {
                foreach (var prop in obj.Properties())
                    if (prop.Value is JArray nested)
                        foreach (var item in nested)
                            list.Add(BsonDocument.Parse(item.ToString()));
            }
            return list;
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        private static JObject DocToJObject(BsonDocument doc)
        {
            // Produce clean JSON (ObjectId -> string, etc.)
            var json = doc.ToJson(RelaxedSettings);
            return JObject.Parse(json);
        }
    }
}
