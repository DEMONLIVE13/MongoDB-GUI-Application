using MongoDB.Bson;
using MongoDB.Driver;

namespace FootballDB.Services
{
    public class MongoService
    {
        private MongoClient?          _client;
        private IMongoDatabase?       _db;

        public bool IsConnected => _client != null && _db != null;
        public string DatabaseName  { get; private set; } = "";

        // ── Connection ────────────────────────────────────────────────────────

        public bool Connect(string connectionString, string databaseName)
        {
            try
            {
                var settings = MongoClientSettings.FromConnectionString(connectionString);
                settings.ServerSelectionTimeout = TimeSpan.FromSeconds(5);
                _client = new MongoClient(settings);
                _db     = _client.GetDatabase(databaseName);
                _db.RunCommand<BsonDocument>(new BsonDocument("ping", 1));
                DatabaseName = databaseName;
                return true;
            }
            catch
            {
                _client = null;
                _db     = null;
                return false;
            }
        }

        public void Disconnect()
        {
            // MongoClient does not implement IDisposable; do not call Dispose().
            // Just clear references so the client can be garbage-collected.
            _client = null;
            _db     = null;
        }

        // ── Helpers ────────────────────────────────────────────────────────────

        private IMongoCollection<BsonDocument> Col(string name) =>
            _db!.GetCollection<BsonDocument>(name);

        // ── Read ───────────────────────────────────────────────────────────────

        public async Task<List<BsonDocument>> GetAllAsync(string collection, int limit = 0)
        {
            var cursor = limit > 0
                ? Col(collection).Find(new BsonDocument()).Limit(limit)
                : Col(collection).Find(new BsonDocument());
            return await cursor.ToListAsync();
        }

        public async Task<long> CountAsync(string collection) =>
            await Col(collection).CountDocumentsAsync(new BsonDocument());

        public async Task<List<BsonDocument>> SearchAsync(string collection, string field, string value)
        {
            var filter = Builders<BsonDocument>.Filter.Regex(field,
                new BsonRegularExpression(value, "i"));
            return await Col(collection).Find(filter).ToListAsync();
        }

        // ── Write ──────────────────────────────────────────────────────────────

        public async Task InsertAsync(string collection, BsonDocument doc)
        {
            doc.Remove("_id");                          // let MongoDB generate _id
            await Col(collection).InsertOneAsync(doc);
        }

        public async Task InsertManyAsync(string collection, List<BsonDocument> docs)
        {
            if (docs.Count == 0) return;
            foreach (var d in docs) d.Remove("_id");
            await Col(collection).InsertManyAsync(docs);
        }

        public async Task UpdateAsync(string collection, ObjectId id, BsonDocument doc)
        {
            doc["_id"] = id;
            var filter = Builders<BsonDocument>.Filter.Eq("_id", id);
            await Col(collection).ReplaceOneAsync(filter, doc, new ReplaceOptions { IsUpsert = false });
        }

        public async Task DeleteAsync(string collection, ObjectId id)
        {
            var filter = Builders<BsonDocument>.Filter.Eq("_id", id);
            await Col(collection).DeleteOneAsync(filter);
        }

        public async Task DeleteManyAsync(string collection, List<ObjectId> ids)
        {
            var filter = Builders<BsonDocument>.Filter.In("_id", ids);
            await Col(collection).DeleteManyAsync(filter);
        }

        public async Task DropCollectionAsync(string collection) =>
            await _db!.DropCollectionAsync(collection);

        // ── Database-level ──────────────────────────────────────────────────────

        public async Task<Dictionary<string, long>> GetCollectionCountsAsync(IEnumerable<string> names)
        {
            var result = new Dictionary<string, long>();
            foreach (var n in names)
            {
                try { result[n] = await CountAsync(n); }
                catch { result[n] = 0; }
            }
            return result;
        }
    }
}
