using FootballDB.Services;
using FootballDB.Windows;
using Microsoft.Win32;
using MongoDB.Bson;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace FootballDB
{
    public partial class MainWindow : Window
    {
        private readonly MongoService   _mongo  = new();
        private readonly DataGenerator  _gen    = new();

        // Per-tab state
        private readonly Dictionary<string, DataGrid>         _grids   = new();
        private readonly Dictionary<string, List<BsonDocument>> _docs  = new();
        private string _activeCollection = "";

        public MainWindow() => InitializeComponent();

        // ══════════════════════════════════════════════════════════════════════
        //  CONNECTION
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnConnect_Click(object sender, RoutedEventArgs e)
        {
            SetStatus("Łączenie…");
            // Read UI values on the UI thread before dispatching to a background thread
            var connStr = (TxtConnStr.Text ?? string.Empty).Trim();
            var dbName  = (TxtDbName.Text  ?? string.Empty).Trim();

            bool ok = await Task.Run(() => _mongo.Connect(connStr, dbName));

            if (ok)
            {
                SetConnected(true);
                BuildTabs();
                await RefreshAllAsync();
                SetStatus($"Połączono z {dbName}");
            }
            else
            {
                SetConnected(false);
                SetStatus("Błąd połączenia — sprawdź adres i port MongoDB.");
                MessageBox.Show("Nie można połączyć z MongoDB.\n\nSprawdź:\n• czy serwer jest uruchomiony\n• adres: " + connStr,
                    "Błąd połączenia", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnDisconnect_Click(object sender, RoutedEventArgs e)
        {
            _mongo.Disconnect();
            SetConnected(false);
            MainTabControl.Items.Clear();
            _grids.Clear();
            _docs.Clear();
            SetStatus("Rozłączono.");
        }

        private void SetConnected(bool connected)
        {
            BtnConnect.IsEnabled    = !connected;
            BtnDisconnect.IsEnabled =  connected;
            DotStatus.Fill          = connected
                ? new SolidColorBrush(Color.FromRgb(0x4C, 0xAF, 0x50))
                : new SolidColorBrush(Color.FromRgb(0xEF, 0x53, 0x50));
            TxtConnStatus.Text      = connected ? "Połączony" : "Rozłączony";
            TxtConnStatus.Foreground= connected
                ? new SolidColorBrush(Color.FromRgb(0x4C, 0xAF, 0x50))
                : new SolidColorBrush(Color.FromRgb(0xEF, 0x53, 0x50));

            // Enable/disable toolbar buttons
            foreach (var btn in new[] { BtnGenerate, BtnImportAll, BtnExportAll,
                                         BtnClearDb, BtnRefreshAll,
                                         BtnAdd, BtnEdit, BtnDelete,
                                         BtnRefreshTab, BtnExportTab, BtnImportTab })
                btn.IsEnabled = connected;
        }

        // ══════════════════════════════════════════════════════════════════════
        //  TAB BUILDING
        // ══════════════════════════════════════════════════════════════════════

        private void BuildTabs()
        {
            MainTabControl.Items.Clear();
            _grids.Clear();

            foreach (var coll in CollectionMeta.Names)
            {
                var dg = new DataGrid
                {
                    Margin = new Thickness(0),
                    Tag    = coll
                };
                dg.MouseDoubleClick += DataGrid_DoubleClick;

                var tab = new TabItem
                {
                    Header  = CollectionMeta.DisplayNames[coll],
                    Content = dg,
                    Tag     = coll
                };

                _grids[coll] = dg;
                MainTabControl.Items.Add(tab);
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  DATA LOADING
        // ══════════════════════════════════════════════════════════════════════

        private async Task LoadCollectionAsync(string coll)
        {
            if (!_mongo.IsConnected) return;
            try
            {
                var docs  = await _mongo.GetAllAsync(coll);
                _docs[coll] = docs;
                var dt    = DocsToDataTable(docs);
                _grids[coll].ItemsSource = dt.DefaultView;
                UpdateRecordCount(docs.Count);
                SetDbInfo(coll, docs.Count);
            }
            catch (Exception ex)
            {
                SetStatus($"Błąd ładowania {coll}: {ex.Message}");
            }
        }

        private async Task RefreshAllAsync()
        {
            if (!_mongo.IsConnected) return;
            foreach (var coll in CollectionMeta.Names)
                await LoadCollectionAsync(coll);
            SetStatus("Wszystkie kolekcje odświeżone.");
        }

        private static DataTable DocsToDataTable(List<BsonDocument> docs)
        {
            var dt = new DataTable();
            if (docs.Count == 0) return dt;

            foreach (var el in docs[0].Elements)
                if (!dt.Columns.Contains(el.Name))
                    dt.Columns.Add(el.Name, typeof(string));

            foreach (var doc in docs)
            {
                var row = dt.NewRow();
                foreach (var el in doc.Elements)
                    if (dt.Columns.Contains(el.Name))
                        row[el.Name] = BsonValueToString(el.Value);
                dt.Rows.Add(row);
            }
            return dt;
        }

        private static string BsonValueToString(BsonValue v) => v.BsonType switch
        {
            BsonType.ObjectId => v.AsObjectId.ToString(),
            BsonType.Null     => "",
            BsonType.Double   => v.AsDouble.ToString("G"),
            BsonType.Int32    => v.AsInt32.ToString(),
            BsonType.Int64    => v.AsInt64.ToString(),
            _                 => v.ToString()
        };

        // ══════════════════════════════════════════════════════════════════════
        //  TAB SELECTION
        // ══════════════════════════════════════════════════════════════════════

        private async void MainTabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MainTabControl.SelectedItem is TabItem tab && tab.Tag is string coll)
            {
                _activeCollection = coll;
                if (_mongo.IsConnected && (!_docs.ContainsKey(coll) || _docs[coll].Count == 0))
                    await LoadCollectionAsync(coll);
                else if (_docs.TryGetValue(coll, out var d))
                    UpdateRecordCount(d.Count);
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  CRUD — ADD
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            var win = new EditWindow(_activeCollection) { Owner = this };
            if (win.ShowDialog() == true && win.ResultDocument != null)
            {
                try
                {
                    await _mongo.InsertAsync(_activeCollection, win.ResultDocument);
                    await LoadCollectionAsync(_activeCollection);
                    SetStatus("Rekord dodany pomyślnie.");
                }
                catch (Exception ex) { ShowError("Błąd dodawania", ex.Message); }
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  CRUD — EDIT
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnEdit_Click(object sender, RoutedEventArgs e) =>
            await EditSelectedAsync();

        private async void DataGrid_DoubleClick(object sender, MouseButtonEventArgs e) =>
            await EditSelectedAsync();

        private async Task EditSelectedAsync()
        {
            if (!EnsureConnected()) return;
            var doc = GetSelectedDoc();
            if (doc == null) { SetStatus("Wybierz rekord do edycji."); return; }

            var win = new EditWindow(_activeCollection, doc) { Owner = this };
            if (win.ShowDialog() == true && win.ResultDocument != null)
            {
                try
                {
                    var id = doc["_id"].AsObjectId;
                    await _mongo.UpdateAsync(_activeCollection, id, win.ResultDocument);
                    await LoadCollectionAsync(_activeCollection);
                    SetStatus("Rekord zaktualizowany.");
                }
                catch (Exception ex) { ShowError("Błąd aktualizacji", ex.Message); }
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  CRUD — DELETE
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            var doc = GetSelectedDoc();
            if (doc == null) { SetStatus("Wybierz rekord do usunięcia."); return; }

            var preview = string.Join(", ", doc.Elements
                .Where(el => el.Name != "_id")
                .Take(3)
                .Select(el => $"{el.Name}: {BsonValueToString(el.Value)}"));

            var res = MessageBox.Show(
                $"Usunąć rekord?\n\n{preview}",
                "Potwierdzenie usunięcia",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (res == MessageBoxResult.Yes)
            {
                try
                {
                    await _mongo.DeleteAsync(_activeCollection, doc["_id"].AsObjectId);
                    await LoadCollectionAsync(_activeCollection);
                    SetStatus("Rekord usunięty.");
                }
                catch (Exception ex) { ShowError("Błąd usuwania", ex.Message); }
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  GENERATOR
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnGenerate_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            var win = new GeneratorWindow() { Owner = this };
            if (win.ShowDialog() != true || win.Result == null) return;

            SetStatus("Generowanie danych…");
            IsEnabled = false;
            try
            {
                var cfg    = win.Result;
                var result = await Task.Run(() => _gen.Generate(cfg));

                foreach (var (coll, docs) in result.Data)
                    await _mongo.InsertManyAsync(coll, docs);

                await RefreshAllAsync();
                var summary = string.Join("  |  ", result.Counts.Select(kv => $"{kv.Key}: +{kv.Value}"));
                SetStatus($"Wygenerowano: {summary}");
                MessageBox.Show(
                    "Generowanie zakończone!\n\n" +
                    string.Join("\n", result.Counts.Select(kv =>
                        $"  {CollectionMeta.DisplayNames.GetValueOrDefault(kv.Key, kv.Key),-22}: +{kv.Value,6}")),
                    "Generator — sukces", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex) { ShowError("Błąd generatora", ex.Message); }
            finally { IsEnabled = true; }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  IMPORT / EXPORT — ALL
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnExportAll_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            var dlg = new SaveFileDialog
            {
                Title      = "Eksportuj całą bazę",
                Filter     = "JSON (*.json)|*.json",
                FileName   = $"footballdb_export_{DateTime.Now:yyyyMMdd_HHmm}.json"
            };
            if (dlg.ShowDialog() != true) return;

            SetStatus("Eksportowanie…");
            try
            {
                var all = new Dictionary<string, List<BsonDocument>>();
                foreach (var coll in CollectionMeta.Names)
                    all[coll] = await _mongo.GetAllAsync(coll);

                await Task.Run(() => ImportExportService.ExportDatabase(all, dlg.FileName));
                int total = all.Values.Sum(v => v.Count);
                SetStatus($"Eksport ukończony — {total} rekordów → {dlg.FileName}");
            }
            catch (Exception ex) { ShowError("Błąd eksportu", ex.Message); }
        }

        private async void BtnImportAll_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            var dlg = new OpenFileDialog { Title = "Importuj bazę z JSON", Filter = "JSON (*.json)|*.json" };
            if (dlg.ShowDialog() != true) return;

            var confirm = MessageBox.Show(
                "Zaimportować dane?\nRekordy zostaną DODANE do istniejących (duplikaty możliwe).",
                "Potwierdzenie importu", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (confirm != MessageBoxResult.Yes) return;

            SetStatus("Importowanie…");
            IsEnabled = false;
            try
            {
                var data = await Task.Run(() => ImportExportService.ImportDatabase(dlg.FileName));
                foreach (var (coll, docs) in data)
                    await _mongo.InsertManyAsync(coll, docs);

                await RefreshAllAsync();
                int total = data.Values.Sum(v => v.Count);
                SetStatus($"Import ukończony — {total} rekordów.");
            }
            catch (Exception ex) { ShowError("Błąd importu", ex.Message); }
            finally { IsEnabled = true; }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  IMPORT / EXPORT — SINGLE COLLECTION
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnExportTab_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            var dlg = new SaveFileDialog
            {
                Title    = $"Eksportuj kolekcję {_activeCollection}",
                Filter   = "JSON (*.json)|*.json",
                FileName = $"{_activeCollection}_{DateTime.Now:yyyyMMdd}.json"
            };
            if (dlg.ShowDialog() != true) return;
            try
            {
                var docs = await _mongo.GetAllAsync(_activeCollection);
                await Task.Run(() => ImportExportService.ExportCollection(docs, dlg.FileName));
                SetStatus($"Eksport {_activeCollection}: {docs.Count} rekordów.");
            }
            catch (Exception ex) { ShowError("Błąd eksportu", ex.Message); }
        }

        private async void BtnImportTab_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            var dlg = new OpenFileDialog { Title = "Importuj kolekcję z JSON", Filter = "JSON (*.json)|*.json" };
            if (dlg.ShowDialog() != true) return;
            try
            {
                var docs = await Task.Run(() => ImportExportService.ImportCollection(dlg.FileName));
                await _mongo.InsertManyAsync(_activeCollection, docs);
                await LoadCollectionAsync(_activeCollection);
                SetStatus($"Zaimportowano {docs.Count} rekordów do {_activeCollection}.");
            }
            catch (Exception ex) { ShowError("Błąd importu", ex.Message); }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  SEARCH
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnSearch_Click(object sender, RoutedEventArgs e) =>
            await PerformSearchAsync();

        private async void TxtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) await PerformSearchAsync();
        }

        private async Task PerformSearchAsync()
        {
            if (!_mongo.IsConnected || string.IsNullOrWhiteSpace(TxtSearch.Text)) return;
            var q = TxtSearch.Text.Trim();
            try
            {
                // Search in name/first_name/last_name fields
                string[] searchFields = { "name", "first_name", "last_name",
                                          "description", "city", "nationality" };
                var results = new List<BsonDocument>();
                foreach (var field in searchFields)
                {
                    var found = await _mongo.SearchAsync(_activeCollection, field, q);
                    results.AddRange(found);
                }
                // Deduplicate by _id
                var unique = results.GroupBy(d => d["_id"]).Select(g => g.First()).ToList();
                _docs[_activeCollection] = unique;
                _grids[_activeCollection].ItemsSource = DocsToDataTable(unique).DefaultView;
                SetStatus($"Znaleziono {unique.Count} wyników dla '{q}' w {_activeCollection}.");
            }
            catch { /* field may not exist in collection — ignore */ }
        }

        private async void BtnClearSearch_Click(object sender, RoutedEventArgs e)
        {
            TxtSearch.Text = "";
            if (_mongo.IsConnected) await LoadCollectionAsync(_activeCollection);
        }

        // ══════════════════════════════════════════════════════════════════════
        //  REFRESH / CLEAR DB
        // ══════════════════════════════════════════════════════════════════════

        private async void BtnRefreshAll_Click(object sender, RoutedEventArgs e) =>
            await RefreshAllAsync();

        private async void BtnRefreshTab_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            await LoadCollectionAsync(_activeCollection);
            SetStatus($"Kolekcja {_activeCollection} odświeżona.");
        }

        private async void BtnClearDb_Click(object sender, RoutedEventArgs e)
        {
            if (!EnsureConnected()) return;
            var res = MessageBox.Show(
                "UWAGA! Usunąć WSZYSTKIE dane ze wszystkich kolekcji?\n\nTej operacji nie można cofnąć.",
                "Wyczyść bazę danych",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (res != MessageBoxResult.Yes) return;

            IsEnabled = false;
            try
            {
                foreach (var coll in CollectionMeta.Names)
                    await _mongo.DropCollectionAsync(coll);
                await RefreshAllAsync();
                SetStatus("Baza danych wyczyszczona.");
            }
            catch (Exception ex) { ShowError("Błąd czyszczenia", ex.Message); }
            finally { IsEnabled = true; }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  HELPERS
        // ══════════════════════════════════════════════════════════════════════

        private BsonDocument? GetSelectedDoc()
        {
            if (!_grids.TryGetValue(_activeCollection, out var dg)) return null;
            if (dg.SelectedIndex < 0) return null;
            if (!_docs.TryGetValue(_activeCollection, out var docs)) return null;
            int idx = dg.SelectedIndex;
            return idx < docs.Count ? docs[idx] : null;
        }

        private bool EnsureConnected()
        {
            if (_mongo.IsConnected) return true;
            SetStatus("Brak połączenia z bazą danych.");
            return false;
        }

        private void SetStatus(string msg)
        {
            TxtActionStatus.Text = msg;
            TxtStatusBar.Text    = $"[{DateTime.Now:HH:mm:ss}] {msg}";
        }

        private void SetDbInfo(string coll, int count) =>
            TxtDbInfo.Text = $"Baza: {_mongo.DatabaseName}  |  {coll}: {count:N0} rek.";

        private void UpdateRecordCount(int n) =>
            TxtRecordCount.Text = n.ToString("N0");

        private static void ShowError(string title, string msg) =>
            MessageBox.Show(msg, title, MessageBoxButton.OK, MessageBoxImage.Error);
    }
}
