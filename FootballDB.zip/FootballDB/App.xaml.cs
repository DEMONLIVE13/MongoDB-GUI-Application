using System.Windows;

namespace FootballDB
{
    public partial class App : Application { }
}
