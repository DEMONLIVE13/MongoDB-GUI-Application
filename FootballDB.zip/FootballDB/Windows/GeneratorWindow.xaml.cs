using FootballDB.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace FootballDB.Windows
{
    public partial class GeneratorWindow : Window
    {
        public GeneratorConfig? Result { get; private set; }

        // (field-name, emoji-label, min, max, default)
        private static readonly (string Key, string Label, int Min, int Max, int Default)[] _rows =
        {
            ("Leagues",      "🏆 Ligi",           1,   50,    5),
            ("Stadiums",     "🏟 Stadiony",        1,   200,  20),
            ("Referees",     "🔶 Sędziowie",       1,   200,  15),
            ("Sponsors",     "🤝 Sponsorzy",       1,   100,  10),
            ("Teams",        "⚽ Drużyny",          2,   500,  40),
            ("Coaches",      "👔 Trenerzy",         1,   500,  50),
            ("Players",      "👟 Zawodnicy",        1,  5000, 800),
            ("Matches",      "🎮 Mecze",            1,  5000, 800),
            ("MatchEvents",  "⚡ Zdarzenia meczów", 1, 50000,5000),
            ("Transfers",    "💰 Transfery",        1,  5000, 500),
            ("TeamSponsors", "🎯 Spons. Drużyn",    1,  1000, 100)
        };

        private readonly Dictionary<string, TextBox>  _boxes   = new();
        private readonly Dictionary<string, Slider>   _sliders = new();

        public GeneratorWindow()
        {
            InitializeComponent();
            BuildRows();
            UpdateTotal();
        }

        // ── Build UI ──────────────────────────────────────────────────────────

        private void BuildRows()
        {
            foreach (var (key, label, min, max, def) in _rows)
            {
                var outer = new Border
                {
                    Background    = new SolidColorBrush(Color.FromRgb(0x16, 0x21, 0x3e)),
                    CornerRadius  = new CornerRadius(6),
                    Padding       = new Thickness(12, 8, 12, 8),
                    Margin        = new Thickness(0, 0, 0, 8)
                };

                var grid = new Grid();
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(185) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(72) });

                // Label
                var lbl = new TextBlock
                {
                    Text              = label,
                    Foreground        = new SolidColorBrush(Color.FromRgb(0xEC, 0xEF, 0xF1)),
                    VerticalAlignment = VerticalAlignment.Center,
                    FontSize          = 13
                };
                Grid.SetColumn(lbl, 0);

                // Slider
                var slider = new Slider
                {
                    Minimum           = min,
                    Maximum           = max,
                    Value             = def,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin            = new Thickness(8, 0, 8, 0),
                    Foreground        = new SolidColorBrush(Color.FromRgb(0x4C, 0xAF, 0x50))
                };
                Grid.SetColumn(slider, 1);

                // TextBox
                var tb = new TextBox
                {
                    Text              = def.ToString(),
                    Width             = 66,
                    TextAlignment     = TextAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    FontWeight        = FontWeights.Bold
                };
                Grid.SetColumn(tb, 2);

                // Wire up events
                slider.ValueChanged += (s, e) =>
                {
                    int v = (int)slider.Value;
                    tb.Text = v.ToString();
                    UpdateTotal();
                };
                tb.TextChanged += (s, e) =>
                {
                    if (int.TryParse(tb.Text, out int v))
                    {
                        v            = Math.Clamp(v, min, max);
                        slider.Value = v;
                        UpdateTotal();
                    }
                };

                _boxes[key]   = tb;
                _sliders[key] = slider;

                grid.Children.Add(lbl);
                grid.Children.Add(slider);
                grid.Children.Add(tb);
                outer.Child = grid;
                RowsPanel.Children.Add(outer);
            }
        }

        // ── Helpers ───────────────────────────────────────────────────────────

        private int GetVal(string key) =>
            int.TryParse(_boxes[key].Text, out int v) ? v : 0;

        private void UpdateTotal()
        {
            int total = _rows.Sum(r => GetVal(r.Key));
            if (TxtTotal != null) TxtTotal.Text = total.ToString("N0");
        }

        private GeneratorConfig BuildConfig() => new()
        {
            Leagues      = GetVal("Leagues"),
            Stadiums     = GetVal("Stadiums"),
            Referees     = GetVal("Referees"),
            Sponsors     = GetVal("Sponsors"),
            Teams        = GetVal("Teams"),
            Coaches      = GetVal("Coaches"),
            Players      = GetVal("Players"),
            Matches      = GetVal("Matches"),
            MatchEvents  = GetVal("MatchEvents"),
            Transfers    = GetVal("Transfers"),
            TeamSponsors = GetVal("TeamSponsors")
        };

        // ── Events ────────────────────────────────────────────────────────────

        private void BtnGenerate_Click(object sender, RoutedEventArgs e)
        {
            Result       = BuildConfig();
            DialogResult = true;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) =>
            DialogResult = false;

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            foreach (var (key, _, min, max, def) in _rows)
            {
                _sliders[key].Value = def;
                _boxes[key].Text    = def.ToString();
            }
            UpdateTotal();
        }
    }
}
