using FootballDB.Services;
using MongoDB.Bson;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace FootballDB.Windows
{
    public partial class EditWindow : Window
    {
        private readonly string _collectionName;
        private readonly bool   _isNew;
        private BsonDocument?   _original;

        // Holds TextBox references keyed by field name
        private readonly Dictionary<string, TextBox> _fields = new();

        public BsonDocument? ResultDocument { get; private set; }

        // ── Constructors ──────────────────────────────────────────────────────

        /// <summary>Open for NEW document (uses schema defaults).</summary>
        public EditWindow(string collectionName)
        {
            InitializeComponent();
            _collectionName = collectionName;
            _isNew          = true;
            TxtIcon.Text    = "➕";
            TxtTitle.Text   = "Nowy rekord";
            TxtSubtitle.Text= CollectionMeta.DisplayNames.GetValueOrDefault(collectionName, collectionName);
            BuildFormFromSchema();
        }

        /// <summary>Open for EXISTING document.</summary>
        public EditWindow(string collectionName, BsonDocument doc)
        {
            InitializeComponent();
            _collectionName = collectionName;
            _isNew          = false;
            _original       = doc;
            TxtIcon.Text    = "✏️";
            TxtTitle.Text   = "Edytuj rekord";
            TxtSubtitle.Text= CollectionMeta.DisplayNames.GetValueOrDefault(collectionName, collectionName);
            BuildFormFromDocument(doc);
        }

        // ── Form building ──────────────────────────────────────────────────────

        private void BuildFormFromSchema()
        {
            if (!CollectionMeta.Fields.TryGetValue(_collectionName, out var defs)) return;
            foreach (var def in defs)
                AddRow(def.Name, def.DefaultValue, def.Hint, isId: false);
        }

        private void BuildFormFromDocument(BsonDocument doc)
        {
            foreach (var el in doc.Elements)
            {
                if (el.Name == "_id") continue;
                string val  = el.Value.BsonType == BsonType.ObjectId
                    ? el.Value.AsObjectId.ToString()
                    : el.Value.ToString()!;
                AddRow(el.Name, val, "", isId: el.Name.EndsWith("_id"));
            }
        }

        private void AddRow(string fieldName, string value, string hint, bool isId)
        {
            var row = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // Label
            var lbl = new TextBlock
            {
                Text       = FieldLabel(fieldName),
                Foreground = new SolidColorBrush(Color.FromRgb(0x90, 0xA4, 0xAE)),
                FontSize   = 11,
                Margin     = new Thickness(0, 0, 0, 2)
            };
            Grid.SetRow(lbl, 0);

            // TextBox
            var tb = new TextBox
            {
                Text        = value,
                Tag         = fieldName,
                IsReadOnly  = (!_isNew && fieldName.EndsWith("_id") && isId)
            };
            if (tb.IsReadOnly)
                tb.Background = new SolidColorBrush(Color.FromRgb(0x1a, 0x2a, 0x40));
            Grid.SetRow(tb, 1);

            _fields[fieldName] = tb;
            row.Children.Add(lbl);
            row.Children.Add(tb);

            // Hint text
            if (!string.IsNullOrWhiteSpace(hint))
            {
                var hintBlock = new TextBlock
                {
                    Text       = hint,
                    Foreground = new SolidColorBrush(Color.FromRgb(0x60, 0x70, 0x70)),
                    FontSize   = 10,
                    Margin     = new Thickness(0, 1, 0, 0),
                    FontStyle  = FontStyles.Italic
                };
                Grid.SetRow(hintBlock, 2);
                row.Children.Add(hintBlock);
            }

            FieldsPanel.Children.Add(row);
        }

        private static string FieldLabel(string name) =>
            System.Globalization.CultureInfo.CurrentCulture
                  .TextInfo.ToTitleCase(name.Replace("_", " "));

        // ── Event handlers ─────────────────────────────────────────────────────

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            HideError();
            try
            {
                var doc = new BsonDocument();

                // Preserve _id for updates
                if (!_isNew && _original != null && _original.Contains("_id"))
                    doc["_id"] = _original["_id"];

                foreach (var (key, tb) in _fields)
                {
                    var raw = tb.Text.Trim();
                    doc[key] = ParseValue(raw);
                }

                ResultDocument = doc;
                DialogResult   = true;
            }
            catch (Exception ex)
            {
                ShowError($"Błąd walidacji: {ex.Message}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) =>
            DialogResult = false;

        // ── Helpers ────────────────────────────────────────────────────────────

        /// <summary>Best-effort value parser: int → long → double → string.</summary>
        private static BsonValue ParseValue(string raw)
        {
            if (string.IsNullOrEmpty(raw))            return BsonNull.Value;
            if (long.TryParse(raw, out long l))        return new BsonInt64(l);
            if (double.TryParse(raw,
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture,
                out double d))                         return new BsonDouble(d);
            return new BsonString(raw);
        }

        private void ShowError(string msg)
        {
            TxtError.Text      = msg;
            ErrorBorder.Visibility = Visibility.Visible;
        }
        private void HideError() => ErrorBorder.Visibility = Visibility.Collapsed;
    }
}
